﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    // 적이 오른쪽으로 이동하는 기능
    // 단, 물리(벨로서티)를 사용하는 방법으로
    Rigidbody2D rigid;

    int dir;
    // Start is called before the first frame update
    void Start()
    {
        rigid = GetComponent<Rigidbody2D>();

        RandomDir();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        //-------------- 내가 쓴 답
        //// 왼쪽, 오른쪽, 안 움직임 세 가지 중에 하나를 랜덤으로
        //int rand = Random.Range(-1, 2);
        //rigid.velocity = new Vector2(rand, rigid.velocity.y);
        //-------------- 내가 쓴 답

        rigid.velocity = new Vector2(dir, rigid.velocity.y);
    }

    void RandomDir()
    {
        // 방향 랜덤으로 정하기
        dir = Random.Range(-1, 2);

        // 랜덤한 주기로 반복
        Invoke("RandomDir", Random.Range(2f, 3f));
    }

}
