using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Enemy : MonoBehaviour
{
    public int hp = 100; // ���� ü��

    public Slider hpBar; // ���� ü�¹�

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    void Damaged(int damage) // ���� ������ ȣ��
    {
        hp -= damage;

        Debug.Log(hp);

        hpBar.value = hp / 100f;
    }

}
